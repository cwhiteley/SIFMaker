require 'acdc'
require 'builder'
require 'hpricot'


module SIFMaker
  
  CO = 'US'
  SPEC = '20r1'  
  
end

require 'sifmaker/us20r1/loader'